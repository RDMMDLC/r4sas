config = config or {}

config.locale = 'en'

--[[
    Do you want to enable automatic harvest and process marker farming?
    false will force the player to press E each time
    true will allow the player to NOT press E each time
]]
config.allowAfkFarming = true